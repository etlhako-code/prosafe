# RxJS in Angular: Creating a Weather App

This is a demo project for the article [RxJS in Angular: Creating a Weather App](https://zoaibkhan.com/blog/rxjs-in-angular-creating-a-weather-app/) published on my blog.

Feel free to extend or modify as you wish :)

Cheers,
Zoaib

