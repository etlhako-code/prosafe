export const environment = {
  firebase: {
    projectId: 'angular-sign-up-719ed',
    appId: '1:378550273300:web:494c048877b2fdaaf62e01',
    storageBucket: 'angular-sign-up-719ed.appspot.com',
    apiKey: 'AIzaSyChyrQOvph3mZt6Sqi2ErZD5FknLvi7n40',
    authDomain: 'angular-sign-up-719ed.firebaseapp.com',
    messagingSenderId: '378550273300',
  },
  production: true
};
